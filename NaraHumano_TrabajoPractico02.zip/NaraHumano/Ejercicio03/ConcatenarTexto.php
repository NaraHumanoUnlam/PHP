<?php
    function concatenar_2_textos($texto1, $texto2){
        return $texto1 . " " . $texto2;
    }
?>